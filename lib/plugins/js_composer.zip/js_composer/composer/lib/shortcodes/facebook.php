<?php
class WPBakeryShortCode_VC_Facebook extends WPBakeryShortCode {
}