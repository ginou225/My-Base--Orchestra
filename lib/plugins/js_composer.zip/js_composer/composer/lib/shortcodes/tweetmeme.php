<?php
class WPBakeryShortCode_VC_TweetMeMe extends WPBakeryShortCode {
}